/********************************************************************
* Marina Vicens Miquel
* COSC 3324
* Dr. Islail Alihan Hadimlioglu
*
* September 9th 2018
*
* Assignment 1 - Introduction to Classes
* Character Part
*
* In this exercise, I created a class called Character that a
* role-playing game might use to represent a character within the
* game. I wrote a test application named CharacterTest that
* demonstrates class Character's capabilities.
********************************************************************/

package characterclass;
import java.io.IOException;
import java.util.InputMismatchException;

import java.util.Scanner;

/**
 *
 * @author mvicensmiquel
 */
public class CharacterClass {

    // Main
    
    public static void main(String[] args) {
        
        Scanner read = new Scanner(System.in); 
        
        // Creating an object
        
        Character myCharacter = new Character();
        
        
        // Variables definition
        
        int strength = 0;
        int dexterity = 0;
        int constitution = 0;
        int intelligence = 0;
        int wisdom = 0;
        int charisma = 0;
        
        
        
         
        try{
            System.out.println("Enter strength: ");
            strength = read.nextInt(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not an integer");
        }
        
        
        try{
            System.out.println("Enter dexterity: ");
            dexterity = read.nextInt(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not an integer");
        }
        
        
        try{
            System.out.println("Enter constitution: ");
            constitution = read.nextInt(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not an integer");
        }
        
        try{
            System.out.println("Enter intelligence: ");
            intelligence = read.nextInt(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not an integer");
        }
        
        
        try{
            System.out.println("Enter wisdom: ");
            wisdom = read.nextInt(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not an integer");
        }
        
        
        try{
            System.out.println("Enter charisma: ");
            charisma = read.nextInt(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not an integer");
        }
       
        
        
        // Function calls
        
        myCharacter.setStrength(strength);
        myCharacter.setDexterity(dexterity);
        myCharacter.setConstitution(constitution);
        myCharacter.setIntelligence(intelligence);
        myCharacter.setWisdom(wisdom);
        myCharacter.setCharisma(charisma);
        
        myCharacter.getStatsTotal();
        
        
        // Calling the function in charge to display the output
        
        System.out.println(myCharacter.CharacterTest());
    
    
    
    }
    
}

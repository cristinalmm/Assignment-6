/********************************************************************
* Marina Vicens Miquel
* COSC 3324
* Dr. Islail Alihan Hadimlioglu
*
* September 9th 2018
*
* Assignment 1 - Introduction to Classes
* Character Part
*
* In this exercise, I created a class called Character that a
* role-playing game might use to represent a character within the
* game. I wrote a test application named CharacterTest that
* demonstrates class Character's capabilities.
********************************************************************/

package characterclass;

/**
 *
 * @author mvicensmiquel
 */
public class Character {
    
    
    // Defining the variables
    
    private int strength;
    private int dexterity;
    private int constitution;
    private int intelligence;
    private int wisdom;
    private int charisma;
    private int statsTotal;
    
    
    // Default constructor
    
    public Character(){
        strength = 0;
        dexterity = 0;
        constitution = 0;
        intelligence = 0;
        wisdom = 0;
        charisma = 0;
        statsTotal = 0;
        
    }
    
    
    // Overloaded constructor
    
    public Character(int charStrength, int charDexterity, int charConstitution, int charIntelligence, int charWisdom, int charCharisma){
        
        strength = charStrength;
        dexterity = charDexterity;
        constitution = charConstitution;
        intelligence = charIntelligence;
        wisdom = charWisdom;
        charisma = charCharisma;
    }
    
    
    // Getter for strength
    
    public int getStrength(){
        return strength;
    }
    
    
    // Setter for strenght
    
    public void setStrength(int setStrength)
    {
        strength = setStrength;
    }
    
    
    // Getter for dexterity
    
    public int getDexterity(){
        return dexterity;
    }
    
    
    // Setter for dexterity
    
    public void setDexterity(int setDexterity)
    {
        dexterity = setDexterity;
    }
    
    
    // Getter for consitution
    
    public int getConstitution(){
        return constitution;
    }
    
    
    // Setter for constitution
    
    public void setConstitution(int setConstitution)
    {
        constitution = setConstitution;
    }
    
    
    // Getter for intelligence
    
    public int getIntelligence(){
        return intelligence;
    }
    
    
    // Setter for intelligence
    
    public void setIntelligence(int setIntelligence)
    {
        intelligence = setIntelligence;
    }
    
    
    // Getter for wisdom
    
    public int getWisdom(){
        return wisdom;
    }
    
    // Setter for wisdom
    
    public void setWisdom(int setWisdom)
    {
        wisdom = setWisdom;
    }
    
    // Getter for charisma
    
    public int getCharisma(){
        return charisma;
    }
    
    
    // Setter for charisma
    
    public void setCharisma(int setCharisma)
    {
        charisma = setCharisma;
    }
    
    
    // Getter for statistics total
    
    public int getStatsTotal()
    {
        statsTotal = strength + dexterity + constitution + intelligence + wisdom + charisma;
        
        if (statsTotal < 0 ){
            statsTotal = 0;
            return statsTotal;
        }
        
        else{
            return statsTotal;
        }
        
    }
    
    // Setter for statistics total
    
    public void setStatsTotal(int setStatsTotal)
    {
        statsTotal = setStatsTotal;
    }
    
    // Function to display the output
    
    public String CharacterTest(){
        return 
                "Strength = " + strength + "\n" + "Dexterity = " + dexterity + "\n" +
                "Constitution = " + constitution + "\n" + "Intelligence = " + 
                intelligence + "\n" + "Wisdom = " + wisdom + "\n" + 
                "Charisma = " + charisma + "\n" + "The total stats are " + statsTotal;
                
                  
    }
    
}

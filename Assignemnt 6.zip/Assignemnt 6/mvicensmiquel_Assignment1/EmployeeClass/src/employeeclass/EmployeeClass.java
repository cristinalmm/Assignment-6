/********************************************************************
* Marina Vicens Miquel
* COSC 3324
* Dr. Islail Alihan Hadimlioglu
*
* September 9th 2018
*
* Assignment 1 - Introduction to Classes
* Employee Part
*
* In this exercise, I created a class called Employee that includes
* three instance variables (first name, last name and monthly
* salary. I created two Employee objects and I displayed each 
* object's yearly salary.
********************************************************************/

package employeeclass;

import java.util.InputMismatchException;
import java.util.Scanner;


/**
 *
 * @author mvicensmiquel
 */
public class EmployeeClass {

    // Main
    
    public static void main(String[] args) {
        
        Scanner read = new Scanner(System.in); 
        
        
        String name = null;
        String lName = null;
        double salary = 0.0;
        
        System.out.println("Enter data for employee one:");
        
        try{
            System.out.println("Enter name: ");
            name = read.nextLine(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a string");
        }
        
        
        try{
            System.out.println("Enter last name: ");
            lName = read.nextLine(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a string");
        }
        
        try{
            System.out.println("Enter salary: ");
            salary = read.nextDouble(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a double");
        }
        
        
        // Creating two objects
    
        Employee myEmployee1 = new Employee(name, lName, salary);
        
        System.out.println("Enter data for employee two:");
        
        try{
            System.out.println("Enter name: ");
            name = read.nextLine(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a string");
        }
        
        
        try{
            System.out.println("Enter last name: ");
            lName = read.nextLine(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a string");
        }
        
        try{
            System.out.println("Enter salary: ");
            salary = read.nextDouble(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a double");
        }
        
        
        Employee myEmployee2 = new Employee(name, lName, salary);
      
        
        // Calling functions to display the outputs
        
        System.out.println(myEmployee1.employeeTest());
        System.out.println(myEmployee2.employeeTest());
    }
    
}

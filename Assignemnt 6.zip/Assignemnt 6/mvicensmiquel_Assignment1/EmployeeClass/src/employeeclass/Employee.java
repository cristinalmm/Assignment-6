/********************************************************************
* Marina Vicens Miquel
* COSC 3324
* Dr. Islail Alihan Hadimlioglu
*
* September 9th 2018
*
* Assignment 1 - Introduction to Classes
* Employee Part
*
* In this exercise, I created a class called Employee that includes
* three instance variables (first name, last name and monthly
* salary. I created two Employee objects and I displayed each 
* object's yearly salary.
********************************************************************/

package employeeclass;

/**
 *
 * @author mvicensmiquel
 */
public class Employee {
    
    // Defining variables
    
    private String firstName;
    private String lastName;
    private double monthlySalary;
    private double yearlySalary;
    private double incrementedYearlySalary;
    
    
    // Default constructor
    public Employee(){
        
    }
    
    
    // Constructor
    
    public Employee(String firstName, String lastName, double monthlySalary){
      this.firstName = firstName;
      this.lastName = lastName;
      this.monthlySalary = monthlySalary;
      this.yearlySalary = 12 * monthlySalary;
      this.incrementedYearlySalary = 1.1 * yearlySalary;
      
      // Setting the value of incrementedYearlySalary to 2 decimal places
       
      String str = String.format("%1.2f", incrementedYearlySalary);
      incrementedYearlySalary = Double.valueOf(str);
      
    }
    
    
    // Getter for first name
    
    public String getFirstName(){
        return firstName;
    }
    
    
    // Setter for first name
    
    public void setFirstName(String setFirstName)
    {
        firstName = setFirstName;
    }
    
    
    // Getter for last name
    
    public String getLastName(){
        return lastName;
    }
    
    
    // Setter for last name
    
    public void setLastName(String setLastName)
    {
        lastName = setLastName;
    }
    
    
    // Getter for monthly salary
    
    public double getMonthlySalary(){
        return monthlySalary;
    }
    
    
    // Setter for monthly salary
    
    public void setMonthlySalary(double setMonthlySalary)
    {
        if (monthlySalary > 0){
            monthlySalary = setMonthlySalary;
        }
    }
    
    // Getter for annual salary
    
    public double getYearlySalary(){
        return yearlySalary;
    }
    
    
    // Setter for annual salary
    
    public void setYearlySalary(double monthlySalary)
    {
        this.yearlySalary = yearlySalary;
    }
    
    
    // Function to display the outputs
    
    public String employeeTest(){
        return 
                "Employee" + "\n" + "First name: " + firstName + "\n" + 
                "Last name: " + lastName + "\n" + "Monthly Salary: $" + 
                monthlySalary + "\n" + "Yearly salary: $" + yearlySalary + "\n" +
                "Incremented yearly salary: $" + incrementedYearlySalary + "\n";    
                  
    }
    
}

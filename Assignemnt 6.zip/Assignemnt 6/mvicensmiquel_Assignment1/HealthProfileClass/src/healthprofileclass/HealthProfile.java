/********************************************************************
* Marina Vicens Miquel
* COSC 3324
* Dr. Islail Alihan Hadimlioglu
*
* September 9th 2018
*
* Assignment 1 - Introduction to Classes
* Health Part
*
* In this exercise, I designed a "starter" HealthProfile class for
* a person. This Java application prompts for the person's 
* information, instantiates an object of class HealthProfile for that
* person and prints the information form that object.
********************************************************************/


package healthprofileclass;

import java.util.InputMismatchException;

/**
 *
 * @author mvicensmiquel
 */
public class HealthProfile {
    
    // Defining variables
    
    private String firstName;
    private String lastName;
    private String gender;
    private String dob;
    private int dobDay;
    private int dobMonth;
    private int dobYear;
    private double height;
    private double weight;
    private int yearsLived;
    private int maxHeartRate;
    private String targetHeartRate;
    private double bmi;
   
    
    // Default constructor
    
    public HealthProfile(){
        
    }
    
    
    // Overloaded constructor

    public HealthProfile(String firstName, String lastName, String gender, String dob,
            double height, double weight){
        
      this.firstName = firstName;
      this.lastName = lastName;
      this.gender = gender;
      this.dob = dob;
      this.height = height;
      this.weight = weight;
    }
    
    
    
    // Getter for the first name
    
    public String getFirstName(){
        return firstName;
    }
    
    
    // Setter for the first name
    
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }
    
    
    // Getter for the last name
    
    public String getLastName(){
        return lastName;
    }
    
    
    // Setter for the last name
    
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }
    
    
    // Getter for the gender
    
    public String getGender(){
        return gender;
    }
    
    
    // Setter for the gender
    
    public void setGender(String gender)
    {
        this.gender = gender;
    }
    
    
    // Getter for day of birth
    
    public int getDobDay(){
        return dobDay;
    }
    
    
    // Setter for day of birth
    
    public void setDobDay(int dobDay)
    {
       
        this.dobDay = dobDay;
    }
    
    
    // Getter for month of birth
    
    public int getDobMonth(){
        return dobMonth;
    }
    
    
    // Setter for month of birth
    
    public void setDobMonth(int dobMonth)
    {
        this.dobMonth = dobMonth;
    }
    
    
    // Getter for year of birth
    
    public int getDobYear(){
        return dobYear;
    }
    
    
    // Setter for year of birth
    
    public void setDobYear(int dobYear)
    {
        this.dobYear = dobYear;
    }
    
    
    // Getter for date of birth
    
    public String getDob(){
        return dob;
    }
    
    
    // Setter for date of birth
    
    public void setDob(String dob)
    {
        this.dob = dob;
    }

    
    // Getter for height
    
    public double getHeight(){
        return height;
    }
    
    
    // Setter for height
    
    public void setHeight(double height)
    {
        this.height = height;
    }
    
    
    // Getter for weight
    
    public double getWeight(){
        return weight;
    }
    
    
    // Setter for weight
    
    public void setWeight(double weight)
    {
        this.weight = weight;
    }
    
 
    // Getter to calculate the age
    
    public int getYearsLived(){
        return yearsLived;
    }
    
    
    // Setter to calculate the age
    
    public void setYearsLived(int dobYear)
    {
        yearsLived = 2018 - dobYear;
    }
    
    
    // Getter for the maximum heart rate
    
    public int getMaxHeartRate(){
        return maxHeartRate;
    }
    
    
    // Setter for the maximum heart rate
    
    public void setMaxHeartRate(int maxHeartRate)
    {
        this.maxHeartRate = maxHeartRate;
    }
    
    
    // Getter for the target heart rate
    
    public String getTargetHeartRate(){
        return targetHeartRate;
    }
    
    
    // Setter for the target heart rate
    
    public void setTargetHeartRate(String targetHeartRate)
    {
       this.targetHeartRate = targetHeartRate;
       
    }
    
    
    // Getter for the Body Mass Index
    
    public double getBmi(){
        return bmi;
    }
    
    
    // Setter for the Body Mass Index
    
    public void setBmi(double weight, double height)
    {
        
        try{
             bmi = (weight / (height * height)) * 703;
        }
        
        catch(ArithmeticException e){
            System.out.println(e.toString());
            System.out.println("Division by zero");
        }
        
        
        
       
        String str = String.format("%1.2f", bmi);
        bmi = Double.valueOf(str);
    }
    
    
    // BMI chart
    
    public String bmiChart(){
        return
                "BMI Chart" + "\n" + "Very severely underweight: from 0 to 15" + "\n" + 
                "Severely underweight: from 15 to 16" + "\n" +
                "Underweight: from 16 to 18.5" + "\n" +
                "Normal (healthy weight): from 18.5 to 25" + "\n" +
                "Overweight: from 25 to 30" + "\n" +
                "Obese Class I (Moderately obese): from 30 to 35" + "\n" +
                "Obese Class II (Severely obese): from 35 to 40" + "\n" +
                "Obese Class III (Very severrelly obese): from 4o to 45";
    }
    
    
    // Output
    
    public String output(){
        return 
                "Health Profile " + "\n" + "First name: " + firstName + "\n" +
                "Last name: " + lastName + "\n" + "Gender: " + gender + "\n" +
                "Date of birth: " + dob + "\n" + "Height: " + height + " inches" 
                + "\n" + "Weight: " + weight + "lbs" + "\n" + "Age: " + yearsLived 
                + "\n" + "Maximum Heart Rate: " + maxHeartRate + "beats per minute" +
                "\n" + "Target Heart Rate: " + targetHeartRate + "\n" + 
                "Body Mass Index (BMI): " + bmi + "\n";
                
                  
    }
}

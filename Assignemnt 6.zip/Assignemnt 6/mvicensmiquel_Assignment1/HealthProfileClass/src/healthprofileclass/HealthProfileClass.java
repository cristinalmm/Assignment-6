/********************************************************************
* Marina Vicens Miquel
* COSC 3324
* Dr. Islail Alihan Hadimlioglu
*
* September 9th 2018
*
* Assignment 1 - Introduction to Classes
* Health Part
* 
* In this exercise, I designed a "starter" HealthProfile class for
* a person. This Java application prompts for the person's 
* information, instantiates an object of class HealthProfile for that
* person and prints the information form that object.
********************************************************************/


package healthprofileclass;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author mvicensmiquel
 */
public class HealthProfileClass {

    // Main
    
    public static void main(String[] args) {
        
        String name = null;
        String lName = null;
        String gender = null;
        String dob = null;
        double height = 0.0;
        double weight = 0.0;
        
        Scanner read = new Scanner(System.in);
        
        
        try{
            System.out.println("Enter name: ");
            name = read.nextLine(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a string");
        }
        
        try{
            System.out.println("Enter last name: ");
            lName = read.nextLine(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a string");
        }
        
        try{
            System.out.println("Enter gener: ");
            gender = read.nextLine(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a string");
        }
        
        try{
            System.out.println("Enter dob: ");
            dob = read.nextLine(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a string");
        }
        
        try{
            System.out.println("Enter height: ");
            height = read.nextDouble(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a double");
        }
        
        try{
            System.out.println("Enter weight: ");
            weight = read.nextDouble(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not a double");
        }
        
        
        // Creating an object
        
        HealthProfile myHealth = new HealthProfile(name, lName, gender, dob, height, weight);
        
        
        
        
        // Calling the functions to display the outputs
        
        System.out.println(myHealth.output());
        System.out.println(myHealth.bmiChart());
        
    }
    
}

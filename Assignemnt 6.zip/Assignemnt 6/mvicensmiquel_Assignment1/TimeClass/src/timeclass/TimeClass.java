/********************************************************************
* Marina Vicens Miquel
* COSC 3324
* Dr. Islail Alihan Hadimlioglu
*
* September 9th 2018
*
* Assignment 1 - Introduction to Classes
* Time Part
*
* In this exercise, I created a class called Time that includes
* three instance variables (hours, minutes and seconds). I wrote
* a test application named TimedTest that demonstrates class
* Time's capabilities.
********************************************************************/

package timeclass;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author mvicensmiquel
*/
public class TimeClass {

    
    // Main
    
    public static void main(String[] args) {
        
        Scanner read = new Scanner(System.in); 
        
        int hours = 0;
        int minutes = 0;
        int seconds = 0;
        
        try{
            System.out.println("Enter hours: ");
            hours = read.nextInt(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not an integer");
        }
        
        try{
            System.out.println("Enter minutes: ");
            minutes = read.nextInt(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not an integer");
        }
        
        try{
            System.out.println("Enter seconds: ");
            seconds = read.nextInt(); 
        }
        
        catch(InputMismatchException e){
            System.out.println(e.toString());
            System.out.println("Not an integer");
        }
        
        

        // Creating an object
    
        Time myTime = new Time(2, 3, 4);
       
        // Function calls
        
        myTime.setHours(2);
        myTime.setMinutes(3);
        myTime.setSeconds(4);
       
        
        // Calling a function to display the output
        
        System.out.println(myTime.timeTest());
        System.out.println(myTime.displayTime());
        
        
    }
    
}

/********************************************************************
* Marina Vicens Miquel
* COSC 3324
* Dr. Islail Alihan Hadimlioglu
*
* September 9th 2018
*
* Assignment 1 - Introduction to Classes
* Time Part
*
* In this exercise, I created a class called Time that includes
* three instance variables (hours, minutes and seconds). I wrote
* a test application named TimedTest that demonstrates class
* Time's capabilities.
********************************************************************/

package timeclass;
import java.util.Scanner;

/**
 *
 * @author mvicensmiquel
 */
public class Time {
    
    // Defining variables
    
    private int hours;
    private int minutes;
    private int seconds;
    boolean check1 = false;
    boolean check2 = false;
    boolean check3 = false;
    Scanner input = new Scanner(System.in);
    
    
    // Default constructor
    
    public Time(int hours, int minutes, int seconds){
      this.hours = 0;
      this.minutes = 0;
      this.seconds = 0;
    }
    
    
    // Getter for hours
    
    public int getHours(){
        return hours;
    }
    
    
    // Setter for hours
    
    public void setHours(int hours)
    {
        // Do-while loop
        
        do{
            // Asking the use to enter the hours
            
            System.out.println("Enter Hours: ");
            
            // Reading the input
            
            hours = input.nextInt();
            
            
            // Validating the hours
            
            if(hours >= 0 && hours < 24){ 
                this.hours = hours; 
                check1 = true;
            }
            
            System.out.println(" ");
            
        }while(check1 == false);
        
    }
    
    
    // Getter for minutes
    
    public int getMinutes(){
        return minutes;
    }
    
    
    // Setter for minutes
    
    public void setMinutes(int minutes)
    {
        // Do-while loop
        
        do{
            // Asking the user to enter the minutes
            
            System.out.println("Enter Minutes: ");
            
            
            // Reding the user's input
            
            minutes = input.nextInt();
            
            
            // Validating the minutes
            if(minutes >= 0 && minutes < 60){ 
                this.minutes = minutes; 
                check2 = true;
            }
            
            System.out.println(" ");
            
        }while(check2 == false);
    }
    
    
    // Getter for the seconds
    
    public int getSeconds(){
        return seconds;
    }
    
    
    // Setter for the seconds
    
    public void setSeconds(int seconds)
    {   
        // Do-while loop
        
        do{
            // Asking the user to enter the seconds
            
            System.out.println("Enter Seconds: ");
            
            
            // Reading the user's input
            
            seconds = input.nextInt();
            
            
            // Validating the seconds
            
            if(seconds >= 0 && seconds < 60){ //condition to put seconds within
                this.seconds = seconds; //the 0-60 seconds limit.
                check3 = true;
            }
            
            System.out.println(" ");
            
        }while(check3 == false);
    }
    
    
    
    // Function used to display the output
    
    public String displayTime(){
        return 
                "Time " + hours + ":" + minutes + ":" + seconds;
                         
    }
    
    // Function used to display the output
    
    public String timeTest(){
        return 
                "Hours: " + hours + "\n" + "Minutes: " + minutes + "\n" +
                "Seconds: " + seconds + "\n";
                         
    }
    
}
